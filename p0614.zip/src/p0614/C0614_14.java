package p0614;

import java.util.Scanner;

public class C0614_14 {

	
	public static void main(String[] args) {
//		
		Scanner scan = new Scanner(System.in);
		System.out.println("숫자를 입력하세요");
		int input = scan.nextInt();
		if (input>0) {
			System.out.println("양수입니다");
		}else if(input<0){
			System.out.println("음수입니다");
		}else {
			System.out.println("0입니다");
		}
		
		
		
//		int a = 11;
//		if (a==10) {
//			System.out.println("10이다");
//		}else {
//			System.out.println("10이 아니다");
//		}
//		
		
		
		
//		int a = 10;
//		if (a>0) {
//			System.out.println("양수");
//		}else {
//			System.out.println("음수");
//			
//		}
//		
//		
	}
}
