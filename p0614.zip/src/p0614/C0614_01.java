package p0614;

public class C0614_01 {

	public static void main(String[] args) {

		
		//논리형
		boolean bol = true;
		boolean bol2 = false;
		
		//문자형
		char ch1 = 'a';
//		char ch2 = 'xx'; // error : 하나의 문자만 가능
		char ch3 = ' ';	// 빈공백(스페이스바)은 저장 가능.
//		char ch4 = '';	// error
		
		//정수형 - byte,short,int,long 타입
//		byte a = 127;	// 127까지
		short b = 2;
//		int c = 2147483647;	// 2147483647까지
		long d = 2147483648L;
		
		//실수형 - float, double 타입
		float e = 3.14F; // 접미사 F 반드시 써야 해
		double f = 3.14; // 접미사 D 생략 가능~
		
		//정수형 - byte,short,int,long 타입
//		int num = 10;
//		System.out.println(num);
		

	}//main

}//class
